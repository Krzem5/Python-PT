package com.krzem.image_editor;



import java.awt.Graphics2D;



public class GUI extends Constants{
	public void _draw(Graphics2D g){
		g.setColor(GUI_BG_COLOR);
		g.fillRect(0,0,WINDOW_SIZE.width,WINDOW_SIZE.height);
	}



	public void draw(Graphics2D g){

	}



	public void update(){

	}
}